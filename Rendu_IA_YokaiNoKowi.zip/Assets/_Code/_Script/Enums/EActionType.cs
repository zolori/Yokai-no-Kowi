namespace YokaiNoMori.Enumeration
{
    public enum EActionType
    {
        PARACHUTE,
        MOVE
    }
}
