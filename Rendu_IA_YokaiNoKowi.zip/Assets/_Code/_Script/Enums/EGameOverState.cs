﻿namespace _Code._Script.Enums
{
    public enum EGameOverState
    {
        None,
        Victory,
        Draw
    }
}