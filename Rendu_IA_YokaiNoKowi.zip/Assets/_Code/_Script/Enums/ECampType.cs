namespace YokaiNoMori.Enumeration
{

    public enum ECampType
    {
        NONE = 0,
        PLAYER_ONE = 1,
        PLAYER_TWO = 2
    }
}
