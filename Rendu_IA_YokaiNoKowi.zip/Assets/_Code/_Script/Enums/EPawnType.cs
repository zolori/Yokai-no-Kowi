namespace YokaiNoMori.Enumeration
{

    public enum EPawnType
    {
        Kodama,
        KodamaSamurai,
        Kitsune,
        Tanuki,
        Koropokkuru
    }
}
